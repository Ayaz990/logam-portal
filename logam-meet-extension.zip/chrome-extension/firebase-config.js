// Firebase configuration for Chrome Extension
const firebaseConfig = {
  apiKey: "AIzaSyApNW2lw2xEuXTl5MdV71Sa4FoGVIoOgIk",
  authDomain: "logam-meet.firebaseapp.com",
  projectId: "logam-meet",
  storageBucket: "logam-meet.firebasestorage.app",
  messagingSenderId: "869899055721",
  appId: "1:869899055721:web:43f31cae7a8c02d9e928f8"
}

// Export for use in extension
window.firebaseConfig = firebaseConfig
