// Centralized API configuration
// Change this URL when deploying to production
const API_URL = 'https://logam-portal.vercel.app' // Production URL

function getApiUrl() {
  return API_URL
}
